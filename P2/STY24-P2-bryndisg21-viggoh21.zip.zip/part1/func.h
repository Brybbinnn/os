int func(int *parg);
